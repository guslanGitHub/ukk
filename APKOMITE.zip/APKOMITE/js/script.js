const label = [
    'AKL',
    'DPIB',
    'OTKP',
    'RPL',
    'TBSM',
    'TPMG',
    'TPTL',
  ];

const data = {
    labels: label,
    datasets: [{
      label: '',
      backgroundColor: [
        'rgb(50, 50, 230)',
        'rgb(230, 100, 100)',
        'rgb(150, 150, 130)',
        'rgb(101, 98, 50)',
        'rgb(87, 120, 90)',
        'rgb(87, 230, 30)',
        'rgb(240, 200, 104)',
      ],
      borderColor: 'rgb(255, 99, 132)',
      data: [70, 50, 120, 145, 105, 45, 50],
    }]
};

  const config = {
    type: 'bar',
    data: data,
    options: {}
  };

  const myChart = new Chart(
    document.getElementById('barSiswa'),
    config
);

const myChart1 = new Chart(
  document.getElementById('barSiswa'),
  config
);