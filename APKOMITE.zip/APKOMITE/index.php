<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- style.css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="fontawesome/css/all.min.css">
  <title>SMK N2 Kaimana</title>
</head>

<body>
  <!-- navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
      <!-- button offcanvas -->
      <button class="navbar-toggler btn btn-secondary bg-dark me-3" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- button offcanvas -->
      <a class="navbar-brand fw-bold text-uppercase me-auto" href="#">smk n2 kaimana</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <form class="d-flex ms-auto">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search" aria-label="Search" aria-describedby="button-addon2">
            <button class="btn btn-primary" type="button" id="button-addon2"><i class="fa-solid fa-magnifying-glass"></i></button>
          </div>
        </form>
        <ul class="navbar-nav mb-2 mb-lg-0">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="fa-solid fa-user"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="profil.html">Profile</a></li>
              <li><a class="dropdown-item" href="#">Setting</a></li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" href="login.html">LogOut</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- navbar -->

  <!-- offcanvas -->
  <div class="offcanvas offcanvas-start sidebar-nav bg-dark" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
    <div class="offcanvas-body text-white py-0 px-0">
      <nav class="navbar-dark">
        <ul class="navbar-nav">
          <li class="">
            <a class="nav-link text-white py-4 px-3 bg-info active" href="index.php">
              <span class="fs-3 me-3"><i class="fa-solid fa-gauge-high"></i></span>
              <span class="fs-4 fw-bold">Dashboard</span>
            </a>
            <hr class="bg-sendary my-0">
          </li>
          <li class="">
            <a class="nav-link py-4 px-3" href="siswa.php">
              <span class="fs-4 me-3"><i class="fa-solid fa-users"></i></span>
              <span class="fw-bold">Daftar Siswa</span>
            </a>
            <hr class="bg-sendary my-0">
          </li>
          <li class="">
            <a class="nav-link py-4 px-3" href="komite.php">
              <span class="fs-4 me-3"><i class="fa-solid fa-money-check"></i></span>
              <span class="fw-bold">Daftar Komite</span>
            </a>
            <hr class="bg-sendary my-0">
          </li>
          <li class="">
            <a class="nav-link py-4 px-3" href="jurusan.php">
              <span class="fs-4 me-3"><i class="fa-solid fa-building-user"></i></span>
              <span class="fw-bold">Daftar Jurusan</span>
            </a>
            <hr class="bg-sendary my-0">
          </li>
          <li class="">
            <a class="nav-link py-4 px-3" href="kelas.php">
              <span class="fs-4 me-3"><i class="fa-solid fa-landmark"></i></span>
              <span class="fw-bold">Daftar Kelas</span>
            </a>
            <hr class="bg-sendary my-0">
          </li>
        </ul>
      </nav>


    </div>
  </div>
  <!-- offcanvas -->

  <!-- main -->
  <main class="mt-5">
    <div class="container-fluid">
      <div class="row py-3">
        <div class="col-md-12">
          <h1 class="display-6 fw-bold ms-3"><i class="fa-solid fa-gauge-high"></i> Dashboard</h1>
          <hr class="bg-secondary">
        </div>
      </div>

      <!-- cards -->
      <div class="row mx-3">
        <div class="col-md-4">
          <div class="card bg-danger py-2 mb-3">
            <div class="card-body">
              <p class="icon-card"><i class="fa-solid fa-users"></i></p>
              <h6 class="card-subtitle mb-2 text-white fs-4">JUMLAH SISWA</h6>
              <p class="card-text display-3 fw-bold text-white">713</p>
              <a href="#" class="card-link text-white">Detail<i class="fa-solid fa-angles-right"></i></a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card bg-info py-2 mb-3">
            <div class="card-body">
              <p class="icon-card"><i class="fa-solid fa-chalkboard-user"></i></p>
              <h6 class="card-subtitle mb-2 text-white fs-4">JUMLAH GURU</h6>
              <p class="card-text display-3 fw-bold text-white">67</p>
              <a href="#" class="card-link text-white">Detail<i class="fa-solid fa-angles-right"></i></a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card bg-success py-2 mb-3">
            <div class="card-body">
              <p class="icon-card"><i class="fa-solid fa-users-gear"></i></p>
              <h6 class="card-subtitle mb-2 text-white fs-4">JUMLAH PETUGAS</h6>
              <p class="card-text display-3 fw-bold text-white">29</p>
              <a href="#" class="card-link text-white">Detail<i class="fa-solid fa-angles-right"></i></a>
            </div>
          </div>
        </div>
        <!-- chart/diagram -->
        <div class="row">
          <!-- untuk diagram data siswa/Jurusan -->
          <div class="col-md-6">
            <div class="card">
              <div class="card-header fw-bold">
                Diagram Data Siswa / Jurusan
              </div>
              <div class="card-body">
                <div>
                  <canvas id="barSiswa"></canvas>
                </div>
                <a href="#" class="btn btn-primary">Detail</a>
              </div>
            </div>
          </div>
          <!-- untuk diagram data siswa perangkatan -->
          <div class="col-md-6">
            <div class="card">
              <div class="card-header fw-bold">
                Diagram Data Siswa / Jurusan
              </div>
              <div class="card-body">
                <div>
                  <canvas id="barSiswa"></canvas>
                </div>
                <a href="#" class="btn btn-primary">Detail</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  <!-- main -->

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

  <!-- javascript chart -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <!-- <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> -->
  <script src="js/script.js"></script>

  <!-- Option 2: Separate Popper and Bootstrap JS -->
  <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
</body>

</html>